<?php 
	$mysql = new mysqli('form-register', 'mysql', 'mysql', 'register');
?>