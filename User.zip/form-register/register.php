<?php require 'header.php'; ?>
<div class="conteiner" style="width: 500px; margin: 50px auto;">
    <div class="row">
        <div class="col">
            <h2>Регистрация</h2>
            <div>
                <input type="text" name="login" class="form-control" id="login" placeholder="Enter login"><br>
                <input type="password" name="password" class="form-control" id="password" placeholder="Enter password"><br>
                <input type="text" name="email" class="form-control" id="email" placeholder="Enter email"><br>
                <input type="text" name="name" class="form-control" id="name" placeholder="Enter name"><br>
                <button class="btn btn-success" id="register">Зарегистрироваться</button>
            </div>
        </div>
    </div>
</div>
