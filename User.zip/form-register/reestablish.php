<?php require 'header.php';?>
<div class="conteiner" style="width: 500px; margin: 50px auto;">
    <div class="row">
        <div class="col">
            <h2>Восстановление пароля</h2>
            <input type="text" name="login" class="form-control" id="login" placeholder="Enter login"><br>
			<input type="password" name="newpassword" class="form-control" id="password" placeholder="Enter new password"><br>
			<button  class="btn btn-success" id="reestablish">Восстановить</button><br><br>
        </div>
    </div>
</div>
